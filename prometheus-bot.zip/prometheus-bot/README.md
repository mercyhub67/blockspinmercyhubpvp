# Prometheus Obfuscator Bot

## ติดตั้ง

### 1. Clone Prometheus
```bash
git clone https://github.com/prometheus-lua/Prometheus.git
```

### 2. ติดตั้ง LuaJIT (หรือ Lua5.1)
```bash
# Ubuntu/Debian
apt install luajit

# Windows — ดาวน์โหลดจาก https://luajit.org/download.html
```

### 3. ติดตั้ง Bot
```bash
npm install
```

### 4. ตั้งค่า .env
```
DISCORD_TOKEN=your_token
PROMETHEUS_CLI=./Prometheus/cli.lua
LUA_BIN=luajit
```

### 5. รัน
```bash
node bot.js
```

---

## คำสั่ง Discord

| คำสั่ง | Preset | ความแรง |
|---|---|---|
| `!obf` + ไฟล์ | Medium | กลาง |
| `!obf strong` + ไฟล์ | Strong | แรงสุด |
| `!obf weak` + ไฟล์ | Minify | เบาสุด (minify เท่านั้น) |
| `!help` | - | แสดงวิธีใช้ |

---

## ทดสอบ CLI ตรงๆ
```bash
luajit ./Prometheus/cli.lua --preset Medium input.lua --out output.lua
luajit ./Prometheus/cli.lua --preset Strong input.lua --out output.lua
```
